
S=MySet([])
print('S=',S)

S=MySet((1,"a","bcd",4,{},9,4.5))
print('S=' ,S)
