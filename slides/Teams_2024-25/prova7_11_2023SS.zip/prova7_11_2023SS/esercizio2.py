

@decoratorFact(int)
class classe1:
	def meth1(self):
		self.w1=dict({'dado': 408, 'sei': 9})
		self.w2=dict({'lancio': 4139})
		self.v1=classe1()
		self._a=3

	def meth2(self):
		self.w3=dict({'pippo': 408, 'topolino': 39})
		self.i=5
		self.e2=classe1()
		self.w4=dict({'paperino': 12, 'minnie': 43})



@decoratorFact(classe1)
class classe2(classe1):
      def __init__(self):
              self.m=classe1()
		


q=classe2()
L=q.addToList()
print("le variabili di istanza di q di tipo classe1 sono:",L)
q.meth1()
L=q.addToList()
print("le variabili di istanza di q di tipo classe1 sono:",L)
q.meth2()
L=q.addToList()
print("le variabili di istanza di q di tipo classe1 sono:",L)
y=classe1()
L=y.addToList()
print("le variabili di istanza di y di tipo int sono:",L)
y.meth1()
L=y.addToList()
print("le variabili di istanza di y di tipo int sono:",L)





"""Il programma deve stampare :

le variabili di istanza di q di tipo classe1 sono: [('m', <__main__.classe1 object at 0x11484f2e0>)]
le variabili di istanza di q di tipo classe1 sono: [('m', <__main__.classe1 object at 0x11484f2e0>), ('v1', <__main__.classe1 object at 0x11484e590>)]
le variabili di istanza di q di tipo classe1 sono: [('m', <__main__.classe1 object at 0x11484f2e0>), ('v1', <__main__.classe1 object at 0x11484e590>), ('e2', <__main__.classe1 object at 0x11484f2b0>)]
le variabili di istanza di y di tipo int sono: []
le variabili di istanza di y di tipo int sono: [('_a', 3)]

"""
