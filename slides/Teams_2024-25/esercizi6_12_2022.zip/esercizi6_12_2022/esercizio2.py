



    

      


def main():
   

    files=["file1","file2","file3","file4"]
    parole=["computer","very","with","is","algorithms"] 

            
    stampaParole(files,parole,2)
    


 

if __name__ == "__main__":
    main()

"""  Ecco cosa deve essere stampato (l'ordine delle righe potrebbe cambiare):
La stringa della lista ['computer', 'very', 'with', 'is', 'algorithms'] che appare il maggior numero di volte nel file file2 e` "very".
Essa appare 3 volte nel file.

La stringa della lista ['computer', 'very', 'with', 'is', 'algorithms'] che appare il maggior numero di volte nel file file1 e` "computer".
Essa appare 48 volte nel file.

La stringa della lista ['computer', 'very', 'with', 'is', 'algorithms'] che appare il maggior numero di volte nel file file4 e` "is".
Essa appare 2 volte nel file.

La stringa della lista ['computer', 'very', 'with', 'is', 'algorithms'] che appare il maggior numero di volte nel file file3 e` "is".
Essa appare 113 volte nel file.

"""

